package com.phomework.waku.shavely.phomework;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.app.NotificationCompat;
import android.telephony.TelephonyManager;
import android.view.KeyEvent;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {

    WebView webView;
    int contar = 0;
    String imei = "NO";
    //String imei = "89571014016061223289";
    String unique = "NO";
    TelephonyManager tm;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        getSupportActionBar().hide();
        webView = (WebView)findViewById(R.id.webview);
        String[] textInicial = {"Phomework","Bienvenido a nuestra App"};
        crearnotificacion(textInicial);

        //tomar el IMEI

        try {
            tm = (TelephonyManager)getSystemService(Context.TELEPHONY_SERVICE);
            imei = tm.getDeviceId();
            unique = tm.getSimSerialNumber();
        }
        catch (Exception e){
            System.out.print("Error "+e.toString());
        }


        webView.setWebViewClient(new MyWebViewClient());
        webView.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.loadUrl("http://phomework.com.co/www/screenshot.html?idtoken="+unique);


        //crear el objeto timer
        Timer timer = new Timer();
        //que actue cada 3000 milisegundos
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                consultanotificaciones(unique);
            }
        }, 0, 5000);
    }

    private class MyWebViewClient extends WebViewClient {
        ProgressDialog progressDialog;
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            view.loadUrl(url);

            return true;
        }
    }

    public void consultanotificaciones(final String codigoIMEI){
        class GetDataJSON extends AsyncTask<String, Void, String> {

            @Override
            protected String doInBackground(String... params){

                List<NameValuePair> parametros;
                try {

                    HttpClient httpclient = new DefaultHttpClient();
                    //crear la instancia de HttpClient que nos permitira enviar peticiones a la url
                    HttpPost httppost = new HttpPost("http://phomework.com.co/www/php/notificaciones/sendAndroidMessage.php");
                    //A;adir parametros
                    parametros = new ArrayList<NameValuePair>();
                    parametros.add(new BasicNameValuePair("codigoIMEI", codigoIMEI));
                    //al momento de finalizar los parametros actualizamos la entidad httppost
                    httppost.setEntity(new UrlEncodedFormEntity(parametros));

                    //finalmente ejecutamos enviando la info al server
                    HttpResponse resp = httpclient.execute(httppost);
                    HttpEntity ent = resp.getEntity();//obtenemos la respuesta

                    String text = EntityUtils.toString(ent);
                    //Tomar la desicion si pasa a la web  o lo sigue intentando
                    String[] arrayText = text.split("-");
                    crearnotificacion(arrayText);
                    System.out.println("Este es el texto traido: "+arrayText[0]);

                    return text;
                }
                catch (Exception e){
                    return e + ".";
                }
            }
        }
        GetDataJSON g = new GetDataJSON();
        g.execute();
    }



    public void crearnotificacion(String[]  arrayText){
        if (arrayText[0]=="SI"){
            //construccion de una notificacion con el usuario.
            notification1(
                    2,
                    R.drawable.ic_os_notification_fallback_white_24dp,
                    arrayText[1],
                    arrayText[2]
            );
        }
    }

    public void notification1(int id, int iconId, String titulo, String contenido) {
        Intent i = new Intent(MainActivity.this, Push.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, i, 0);
        NotificationManager nm = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);

        //creacion de la notificacion
        Notification noti = new NotificationCompat.Builder(this)
                .setContentIntent(pendingIntent)
                .setTicker("Phomework")
                .setContentTitle(titulo)
                .setContentText(contenido)
                .setSmallIcon(R.drawable.ic_os_notification_fallback_white_24dp)
                .addAction(R.drawable.ic_os_notification_fallback_white_24dp, " ", pendingIntent)
                .setVibrate(new long[] {100, 250, 100, 500})
                .build();
        nm.notify(id, noti);

    }


    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        WebView mWebView;
        mWebView = (WebView) findViewById(R.id.webview);
        if (event.getAction() == KeyEvent.ACTION_DOWN) {
            switch (keyCode) {
                case KeyEvent.KEYCODE_BACK:
                    if (mWebView.canGoBack()) {
                        mWebView.goBack();
                    } else {
                        finish();
                    }
                    return true;
            }
        }
        return super.onKeyDown(keyCode, event);
    }



}
