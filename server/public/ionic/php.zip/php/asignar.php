<?php

/***

Licencia por wakusoft

****/



if(isset($_POST['encrypt'])){

    if($_POST['aceptado']!=''){

        ejecutar();

    }

    else{

        echo 'NOPERMISOS';

    }

}

else{

    echo 'NO';

}


function ejecutar(){

	//importar librerias de conexion

	include_once "conexion.php"; 

	$conexion = conexion();
	//traer datos POST


  $idtarea = $_POST['tarea'];

  $docente = $_POST['aceptado'];

	mysqli_query($conexion,"UPDATE `tareas` SET `idprofesor` = $docente WHERE `tareas`.`idtareas` = ".$idtarea." ;") or die(mysqli_error($conexion));

	mysqli_query($conexion,"UPDATE `solicitudTareas` SET `aceptado` = 1  WHERE `id_docente` = $docente AND `id_tarea` = $idtarea ORDER BY `aceptado` DESC") or die(mysqli_error($conexion));

  $tareas = mysqli_query($conexion,"SELECT * FROM tareas WHERE `tareas`.`idtareas` = ".$idtarea." ;") or die(mysqli_error($conexion));
  $row = $tareas->fetch_assoc();
  $idestudiante = $row['idestudiante'];
  $hoy  = date('Y-m-d');
  $mensaje = 'la tarea '.$idtarea.' Esta disponible para que tu la soluciones <a href="http://phomework.com.co/www/menuDocente/MostrarTarea.html?id='.$idtarea.'&estudiante='.$idestudiante.'&docente='.$docente.'">Ingresa aqui</a>' ;
      $sql = "INSERT INTO `notificaciones` (`id`, `titulo`, `texto`, `estudiante`, `docente`, `fecha_creado`, `fecha_actualizado`, `estado`) VALUES (NULL, 'Phomework Tarea Nueva', '$mensaje', '0', '$docente', '$hoy', '$hoy', '1')";
      mysqli_query($conexion, $sql) or die(mysqli_error($conexion)); 
      exit();

  $docentes = mysqli_query($conexion,"SELECT * FROM `profesores` WHERE `idprofesores` = $docente") or die(mysqli_error($conexion));
  $row = $docentes->fetch_assoc;
  echo 'Asignada';
	enviar_correo($row['correo'],$mensaje);
}

function enviar_correo($correo,$mensaje){
    $mensaje = '<html><head><title>Bienvenido a Phomework</title><meta charset="utf-8"></head><body><div style="background:#dbdbdb;width: 94%;text-align: center;border: 1px solid white;border-radius: 10px 10px 10px 10px;-moz-border-radius: 10px 10px 10px 10px;-webkit-border-radius: 10px 10px 10px 10px;border: 0px solid #000000;padding: 10px;font-family: sans-serif;font-size:12px;color:#666666;">
    <div style="float:left;"><img style="width:60px;" src="http://phomework.com.co/www/image/phome-ico.png"></div>
    <h1 style="color:white"> '.$mensaje.' </h1></body></html>';
    $para = $correo;
    $asunto = "Habilitado para solucionar tarea ";
    //Librerías para el envío de mail
    include_once('PHPMailer/class.phpmailer.php');
    include_once('PHPMailer/class.smtp.php');
    //Este bloque es importante
    $mail = new PHPMailer();
    $mail->IsSMTP();
    $mail->SMTPAuth = true;
    $mail->IsHTML(true);
    $mail->SMTPSecure = "tls";
    $mail->Host = "smtp.gmail.com";
    $mail->Port = 587;     
    //Nuestra cuenta
    $mail->Username ='wakusoft@gmail.com';
    $mail->Password = 'wakusoft2016'; //Su password
    //Agregar destinatario
    $mail->FromName = "Phomework APP";
    $mail->AddAddress($para);
    $mail->Subject = $asunto;
    $mail->Body = $mensaje;
    $mail->Send();
}



?>