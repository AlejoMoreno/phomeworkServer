<?php 
/***
Licencia por wakusoft
****/

require_once('class/mailNotify.php');


if(isset($_POST['encrypt'])){
    if($_POST['nombre']!=''){
        ejecutar();
        $mail = new mailNotify();
        $mail->params($_POST['correo'],'Bienvenido a Phomework');
        $mail->send(
            $mail->mensajeDocenteRegistro(
                $_POST['nombre'].' '.$_POST['apellido'],
                $_POST['clave']
                ));
        echo 'OK';
    }
    else{
        echo 'NOPERMISOS';
    }
}
else{
    echo 'NO';
}


function ejecutar(){
    //incluir librerias de conexion
    include_once "conexion.php"; 
    $conexion = conexion();
    //traer datos POST
    $nombre = $_POST['nombre'];
    $apellido = $_POST['apellido'];
    $correo = $_POST['correo'];
    $telefono = $_POST['telefono'];
    $direccion = $_POST['direccion'];
    $idadministrador = $_POST['idadministrador'];
    $idareasEspecialista = $_POST['idareasEspecialista'];
    $clave = $_POST['clave'];
    $claveRepeat = $_POST['claveRepeat'];
    $descripcion = $_POST['descripcion'];
    $cuenta = $_POST['cuenta'];
    $tipocuenta = $_POST['tipocuenta'];
    $banco = $_POST['banco'];
    /*subir foto y certificado*/
        //$imagen_subida1 = subir_certificado();
        //$imagen_subida = subir_foto();
    //insertar en la base de datos
    $encriptada= md5($clave);
    $profesores = mysqli_query($conexion,"SELECT * FROM profesores WHERE correo like '$correo' ") or die(mysqli_error($conexion));
    $estudiantes = mysqli_query($conexion,"SELECT * FROM estudiantes WHERE  correo like '$correo'") or die(mysqli_error($conexion));
    if(mysqli_num_rows($profesores)>0){
        echo 'Correo ya se encuentra registrado';
        exit();
    }
    elseif(mysqli_num_rows($estudiantes)>0){
        echo 'Correo ya se encuentra registrado';
        exit();
    }
    else{
        $sql = "INSERT INTO `profesores` (`idprofesores`, `nombre`, `apellido`, `urlFoto`, `correo`, `telefono`, `direccion`, `urlCertificado`, `estado`, `idadministrador`, `idareasEspecialista`, `clave`, `descripcion`, `tipo`, `cuenta`, `tipocuenta`, `banco`) VALUES (null, '$nombre', ' $apellido', '$imagen_subida', '$correo', '$telefono', '$direccion', '$imagen_subida1', '1', '2', '$idareasEspecialista', '$encriptada', '$descripcion', 'docente', '$cuenta', '$tipocuenta', '$banco');";
        mysqli_query($conexion, $sql) or die(mysqli_error($conexion)); 

        /*Integracion de notificacion*/
        $docente = mysqli_query($conexion, "SELECT * FROM profesores WHERE correo like '$correo' " ) or die(mysqli_error($conexion)); 
        $hoy = date('y-m-d');
        $docen = $docente->fetch_assoc();
        $idprofesores = $docen['idprofesores'];
            include_once "notificaciones/onlyMessage.php";
            $respuesta = sendMessage('Bienvenido a Phomework App', $docen['tipo']);
            $sql = "INSERT INTO `notificaciones` (`id`, `titulo`, `texto`, `estudiante`, `docente`, `fecha_creado`, `fecha_actualizado`, `estado`) VALUES (NULL, 'Bienvenido a Phomework', 'Trabaja de forma comoda en tu celular, ganando dinero haciendo lo que sabes hacer. ', '0', '$idprofesores', '$hoy', '$hoy', '1');";
            mysqli_query($conexion, $sql) or die(mysqli_error($conexion));

    }     
}

function subir_certificado(){
    $dir_destino = '../certificados/';
    $imagen_subida1 = $dir_destino . basename($_FILES['urlCertificado']['name']);
    if(!is_writable($dir_destino)){
        $log = "no tiene permisos";
    }
    else{
        if(is_uploaded_file($_FILES['urlCertificado']['tmp_name'])){
            if (move_uploaded_file($_FILES['urlCertificado']['tmp_name'], $imagen_subida1)) {
                $log =  "El archivo es fue cargado exitosamente.\n";
            } 
            else {
                $log =  "Posible ataque de carga de archivos!\n";
            }
        }
        else{
            $log =  "Posible ataque del archivo subido: ";
            $log =  "nombre del archivo '". $_FILES['archivo_usuario']['tmp_name'] . "'.";
        }
    }
    return $imagen_subida1;
}

function subir_foto(){
    $dir_destino = '../fotosdocentes/';
    $imagen_subida = $dir_destino . basename($_FILES['urlFoto']['name']);
    if(!is_writable($dir_destino)){
        $log =  "no tiene permisos";
    }
    else{
        if(is_uploaded_file($_FILES['urlFoto']['tmp_name'])){
            if (move_uploaded_file($_FILES['urlFoto']['tmp_name'], $imagen_subida)) {
                $log =  "El archivo es fue cargado exitosamente.\n";
            }
            else {
                $log =  "Posible ataque de carga de archivos!\n";
            }
        }
        else{
            $log =  "Posible ataque del archivo subido: ";
            $log =  "nombre del archivo '". $_FILES['archivo_usuario']['tmp_name'] . "'.";
        }
    }
    return $imagen_subida;
}


?>