<?php 

echo 'hola';

?>