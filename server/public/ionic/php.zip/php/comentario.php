<?php 
/***
Licencia por wakusoft
****/

if(isset($_POST['encrypt'])){
    if($_POST['correo']!=''){
        ejecutar();
        echo 'OK';
    }
    else{
        echo 'NOPERMISOS';
    }
}
else{
    echo 'NO';
}

function ejecutar(){
    //incluir librerias de conexion
    include_once "conexion.php"; 
    $conexion = conexion();
    //tomar los datos
    $comentario = $_POST['comentario'];
    $correo = $_POST['correo'];
    $id = $_POST['id'];
    $sql = "INSERT INTO `testimonios_blog` (`idtestimoniosBlog`, `testimonio`, `idestudiante`, `correo`) VALUES (NULL, '$comentario', '$id', '$correo');";
    mysqli_query($conexion, $sql) or die(mysqli_error($conexion)); 

}


?>