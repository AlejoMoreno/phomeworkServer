
<?php
$server = "localhost";
$bd = "leizycom_phomework";
$user = "root";
$pas = "";
$con = mysqli_connect($server, $user, $pas, $bd);//ConexiÃ³n a la base de datos
?>