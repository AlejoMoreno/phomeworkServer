<?php
/***
Licencia por wakusoft
****/
if(isset($_POST['encrypt'])){
    if($_POST['nombre']!=''){
        ejecutar();
    }
    else{
        echo 'NOPERMISOS';
    }
}
else{
    echo 'NO';
}

function ejecutar(){
    include_once "conexion.php"; 
    $conexion = conexion();

    $idestudiante = $_POST['id'];
    $nombre = $_POST['nombre'];
    $valor = $_POST['valor'];
    $descripcion = $_POST['descripcion'];
    $fecha_creacion = date("Y-m-d");
    $fecha_vencimiento = $_POST['fecha_vencimiento'];
    $estado = 'EN ESPERA';
    $calificacion = $_POST['calificacion'];
    $sql = "INSERT INTO `tareas` (`idtareas`, `nombre`, `urltarea`, `calificacion`, `estado`, `idestudiante`, `valor`, `descripcion`, `fecha_creacion`, `fecha_vencimiento`, `idprofesor`) VALUES (NULL, '$nombre', null, '$calificacion', '$estado', $idestudiante, '$valor', '$descripcion', '$fecha_creacion', '$fecha_vencimiento', '1');";

    mysqli_query($conexion, $sql) or die(mysqli_error($conexion));

    $bill = mysqli_query($conexion,"SELECT * FROM tareas where `idestudiante` = '$idestudiante' ORDER BY `tareas`.`idtareas` DESC") or die(mysqli_error($conexion));
    if($row = $bill->fetch_assoc()){
        echo $row["idtareas"];
        $tarea = $row["idtareas"];
    }      


}

?>