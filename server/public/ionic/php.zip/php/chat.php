<?php 
/***
Licencia por wakusoft
****/

if(isset($_POST['encrypt'])){
    if($_POST['tipo']!=''){
        ejecutar();
        //echo 'OK';
    }
    else{
        echo 'NOPERMISOS';
    }
}
else{
    echo 'NO';
}

function ejecutar(){
    //incluir librerias de conexion
    include_once "conexion.php"; 
    $conexion = conexion();
    $fecha_creacion = date("Y-m-d");
    //tomar los datos
    $estudiante = $_POST['receptor'];
    $docente = $_POST['emisor'];
    $mensaje = $_POST['mensaje'];
    
    if($_POST['tipo']=='docente'){
      $vs = $_POST['receptor'].'-'.$_POST['emisor'];
      $receptor = $_POST['receptor'];
      $emisor = $_POST['emisor'];
      //registro de notificacion
      $hoy  = date('Y-m-d');
      $href = "<a href=chat.html?docente=".$emisor."&estudiante=".$receptor."><img width=30 src=https://image.flaticon.com/icons/svg/402/402306.svg></a>";
      $sql = "INSERT INTO `notificaciones` (`id`, `titulo`, `texto`, `estudiante`, `docente`, `fecha_creado`, `fecha_actualizado`, `estado`) VALUES (NULL, 'Phomework Chat de: $emisor', '$mensaje <br> $href', '$receptor', '0', '$hoy', '$hoy', '1')";
      mysqli_query($conexion, $sql) or die(mysqli_error($conexion)); 
    }
    else{
      $vs = $_POST['emisor'].'-'.$_POST['receptor'];
      $receptor = $_POST['emisor'];
      $emisor = $_POST['receptor'];
      //registro notificacion
      $hoy  = date('Y-m-d');
      $href = "<a href=chat.html?estudiante=".$emisor."&docente=".$receptor."><img width=30 src=https://image.flaticon.com/icons/svg/402/402306.svg></a>";
      $sql = "INSERT INTO `notificaciones` (`id`, `titulo`, `texto`, `estudiante`, `docente`, `fecha_creado`, `fecha_actualizado`, `estado`) VALUES (NULL, 'Phomework Chat de: $emisor', '$mensaje <br> $href', '0', '$receptor', '$hoy', '$hoy', '1')";
      mysqli_query($conexion, $sql) or die(mysqli_error($conexion)); 
    }
    
    if($mensaje!=''){
    	$sql = "INSERT INTO `chat` (`idchat`, `idestudiante`, `idprofesor`, `mensaje`, `fecha`, `estado`, `vs`) VALUES (NULL, '$estudiante', '$docente', '$mensaje', '$fecha_creacion', 'enviado', '$vs');";
	    mysqli_query($conexion, $sql) or die(mysqli_error($conexion)); 
    }
    
    //buscar el chat entre 
   	$chat = mysqli_query($conexion,"SELECT * FROM `chat` WHERE `idestudiante` = $estudiante AND `idprofesor` = $docente ORDER BY `chat`.`idchat` DESC ") or die(mysqli_error($conexion));
   	$resultado = '';
   	while ($row = $chat->fetch_assoc()){
   		$arrayVS = explode("-", $row['vs']);
   		if($arrayVS[0]==$row['idestudiante']){
   			$resultado .= '
	    	<div class="msm" style="text-aling: right; background: #ebe9f9;width: 100%;padding: 10px;"><h5>'.$row['idprofesor'].'</h5><p>'.$row['mensaje'].'</p><span style="float: right;font-size: 11px;">'.$row['fecha'].'</span></div><br>';?>
     



<head>
<script src="../js/push.min.js"></script>
</head>
<body>
<script >
  
/*Push.create("Hola", {
    body: "Tienes un mensaje nuevo",
    icon: 'icon.png',
    timeout: 4000,
    onClick: function () {
        window.focus();
        this.close();
    }
});*/
  
</script>

</body>
<?php
   		}
   		else{
   			$resultado .= '
	    	<div class="msm" style="text-aling: left; background: #c1bfea;width: 100%;padding: 10px;"><h5>'.$row['idestudiante'].'</h5><p>'.$row['mensaje'].'</p><span style="float: right;font-size: 11px;">'.$row['fecha'].'</span></div><br>';?>
     



<head>
<script src="../js/push.min.js"></script>
</head>
<body>
<script >
  
/*Push.create("Hola", {
    body: "Tienes un mensaje nuevo",
    icon: 'icon.png',
    timeout: 4000,
    onClick: function () {
        window.focus();
        this.close();
    }
});
  */
</script>

</body>
<?php
   		}
   			
   	}

   	$resultado .= '';

   	//echo $resultado;
    

}


?>