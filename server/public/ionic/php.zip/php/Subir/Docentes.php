<?php



exec('whoami');



$target_path = "Documentos/";

$target_path = $target_path . 'doc_'.uniqid().'.'.explode('.', $_FILES['file']['name'])[1];

if(move_uploaded_file($_FILES['file']['tmp_name'], $target_path)) {

    //echo "The file ". basename( $_FILES['file']['name'])." has been uploaded";

    $ext = explode('.', $_FILES['file']['name'])[1];
    if($ext == 'docx' || $ext == 'doc' || $ext == 'pptx' || $ext == 'xlsx' || $ext == 'xls' || $ext == 'ppt' ){
         echo '<div ><div class="thumbnal">
                    <iframe src="http://docs.google.com/gview?url=http://'.$_SERVER['HTTP_HOST'].'/www/php/Subir/'.$archivos['url'].'&embedded=true" width="275" height="275"></iframe>
                </div></div>';
    }
    elseif($ext == 'pdf'){
        echo '<div ><div class="thumbnal">
                    <iframe src="http://docs.google.com/gview?url=http://'.$_SERVER['HTTP_HOST'].'/www/php/Subir/'.$archivos['url'].'&embedded=true" width="275" height="275"></iframe>
                </div></div>';
    }
    elseif($ext == 'mp4' || $ext == 'mp3' || $ext == 'avg' || $ext == 'wmv' || $ext == 'flv' || $ext == 'mov'){
        echo '<video controls width="275" height="275" style="background:black;">
              <source src="http://'.$_SERVER['HTTP_HOST'].'/www/php/Subir/'.$archivos['url'].'" type="video/mp4">
              <source src="http://'.$_SERVER['HTTP_HOST'].'/www/php/Subir/'.$archivos['url'].'" type="video/ogg">
              Your browser does not support the video tag.
            </video>';
    }
    elseif($ext == 'png' || $ext == 'tif' || $ext == 'jpg' || $ext == 'jpeg' || $ext == 'gif' || $ext == 'bmp'){
        echo '<img src="http://'.$_SERVER['HTTP_HOST'].'/www/php/Subir/'.$archivos['url'].'" width="275" height="275">
              <a href="http://'.$_SERVER['HTTP_HOST'].'/www/php/Subir/'.$archivos['url'].'">Descargar</a>';
    }
    else{
        echo '<div ><div class="thumbnil">
                  <iframe src="http://docs.google.com/gview?url=http://'.$_SERVER['HTTP_HOST'].'/www/php/Subir/'.$archivos['url'].'&embedded=true" width="275" height="275"></iframe>
                </div></div>';
    }

    //echo "<a href='http://".$_SERVER['HTTP_HOST']."/www/php/Subir/".$target_path."'><img width='150' id='zoom' class='zoom' src='http://".$_SERVER['HTTP_HOST']."/www/php/Subir/".$target_path."' onclick='this.classList.add('zoom1');'></a>";
   // echo "<embed src='http://".$_SERVER['HTTP_HOST']."/www/php/Subir/".$target_path."#toolbar=0' width='500' height='375'>";

    //verCertificados();

    ejecutar($target_path);

} 

else{

    echo "There was an error uploading the file, please try again!";

}



function ejecutar($src){

    include_once "../conexion.php"; 

    $conexion = conexion();

    $id = buscar();

     $sql = "INSERT INTO `certificados` (`id`, `url`, `docente`) VALUES (NULL, '$src', '$id');";

    mysqli_query($conexion, $sql) or die(mysqli_error($conexion)); 

}


function buscar(){
        //importar librerias de conexion

    include_once "../conexion.php"; 

    $conexion = conexion();

    //traer datos POST
    $correo = '';

    $correo = $_POST['correo'];

    $profesores = mysqli_query($conexion,"SELECT * FROM profesores WHERE correo like '$correo' limit 1") or die(mysqli_error($conexion));

    //verifiacciones

    $row = $profesores->fetch_assoc();

    $id = $row['idprofesores'];

    return $id;

}


function verCertificados(){

    include_once "../conexion.php"; 

    $conexion = conexion();

    $id = buscar();

    $certificados = mysqli_query($conexion,"SELECT * FROM certificados WHERE docente like '$id' ") or die(mysqli_error($conexion));

    //verifiacciones

    while($row = $certificados->fetch_assoc()){

        echo "<a href='http://".$_SERVER['HTTP_HOST']."/www/php/Subir/".$row['url']."'><img width='150' id='zoom' class='zoom' src='http://".$_SERVER['HTTP_HOST']."/www/php/Subir/".$row['url']."' onclick='this.classList.add('zoom1');'></a>";

    }

}


/*

if (isset($_FILES["file"]))

{

    //$host = 'http://localhost:8080/www/php/Subir/';

    //host = 'http://phomework.com.co/www/';

    $dir_destino = 'Documentos/';

    $imagen_subida1 = $dir_destino . basename($_FILES['file']['name']);

    if(is_writable($dir_destino)){

        echo "no tiene permisos";

        echo $imagen_subida1;

    }

    else{

        if(is_uploaded_file($_FILES['file']['tmp_name'])){

            if (move_uploaded_file($_FILES['file']['tmp_name'], $imagen_subida1)) {

                echo  "El archivo es fue cargado exitosamente.\n";

                $src = $imagen_subida1;

                echo "<img width='150' src='$src'>";

                //ejecutar($src);

            } 

            else {

                echo "Posible ataque de carga de archivos!\n";

            }

        }

        else{

            echo  "Posible ataque del archivo subido: ";

            echo  "nombre del archivo '". $_FILES['file']['tmp_name'] . "'.";

        }

    }

}

else{

    echo 'NO';

}



function ejecutar($src){

    //importar librerias de conexion

    include_once "../conexion.php"; 

    $conexion = conexion();

    //traer datos POST

    $correo = $_POST['correo'];

    $profesores = mysqli_query($conexion,"SELECT * FROM profesores WHERE correo like '$correo'") or die(mysqli_error($conexion));

    //verifiacciones

    $row = $profesores->fetch_assoc();

    $id = $row['idprofesores'];

     $sql = "INSERT INTO `certificados` (`id`, `url`, `docente`) VALUES (NULL, '$src', '$id');";

    mysqli_query($conexion, $sql) or die(mysqli_error($conexion)); 

}*/

?>