<?php



exec('whoami');



$target_path = "Tareas/";

$target_path = $target_path . 'doc_'.uniqid().'.'.explode('.', $_FILES['file']['name'])[1];

if(move_uploaded_file($_FILES['file']['tmp_name'], $target_path)) {

    //echo "The file ". basename( $_FILES['file']['name'])." has been uploaded";
    $ext = explode('.', $_FILES['file']['name'])[1];
    if($ext == 'docx' || $ext == 'doc' || $ext == 'pptx' || $ext == 'xlsx' || $ext == 'xls' || $ext == 'ppt' ){
         echo '<div ><div class="thumbnal">
                    <iframe src="http://docs.google.com/gview?url=http://'.$_SERVER['HTTP_HOST'].'/www/php/Subir/'.$target_path.'&embedded=true" width="275" height="275"></iframe>
                </div></div>';
    }
    elseif($ext == 'pdf'){
        echo '<div ><div class="thumbnal">
                    <iframe src="http://docs.google.com/gview?url=http://'.$_SERVER['HTTP_HOST'].'/www/php/Subir/'.$target_path.'&embedded=true" width="275" height="275"></iframe>
                </div></div>';
    }
    elseif($ext == 'mp4' || $ext == 'mp3' || $ext == 'avg' || $ext == 'wmv' || $ext == 'flv' || $ext == 'mov' || $ext == 'm4a'){
        echo '<video controls width="275" height="275" style="background:black;">
              <source src="http://'.$_SERVER['HTTP_HOST'].'/www/php/Subir/'.$target_path.'" type="video/mp4">
              <source src="http://'.$_SERVER['HTTP_HOST'].'/www/php/Subir/'.$target_path.'" type="video/ogg">
              Your browser does not support the video tag.
            </video>';
    }
    elseif($ext == 'png' || $ext == 'tif' || $ext == 'jpg' || $ext == 'jpeg' || $ext == 'gif' || $ext == 'bmp'){
        echo '<img src="http://'.$_SERVER['HTTP_HOST'].'/www/php/Subir/'.$target_path.'" width="275" height="275">
              <a href="http://'.$_SERVER['HTTP_HOST'].'/www/php/Subir/'.$target_path.'">Descargar</a>';
    }
    else{
        echo '<div ><div class="thumbnil">
                  <iframe src="http://docs.google.com/gview?url=http://'.$_SERVER['HTTP_HOST'].'/www/php/Subir/'.$target_path.'&embedded=true" width="275" height="275"></iframe>
                </div></div>';
    }

    
    ejecutar($target_path); 

} 

else{

    echo "There was an error uploading the file, please try again!";

}



function ejecutar($src){

    //importar librerias de conexion

    include_once "../conexion.php"; 

    $conexion = conexion();

    //traer datos POST

    $idtarea = $_POST['idtarea'];

    $sql = "INSERT INTO `archivos` (`ida`, `url`, `idtarea`) VALUES (NULL, '$src', $idtarea);";

    //echo $sql;
    mysqli_query($conexion, $sql) or die(mysqli_error($conexion)); 

}




?>