<?php 

include_once "conexion.php"; 
    $conexion = conexion();

    $idtarea = $_POST['idtarea'];
    $calificacion = $_POST['calificacion'];
    $comentarios = $_POST['comentarios'];

$sql = "INSERT INTO `calificaciones` (`id`, `idtarea`, `calificacion`, `comentarios`) VALUES (NULL, '$idtarea', '$calificacion', '$comentarios');";

       mysqli_query($conexion, $sql) or die(mysqli_error($conexion));

?>