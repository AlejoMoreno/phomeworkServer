<?php 
/***
Licencia por wakusoft
****/
require_once('class/mailNotify.php');

if(isset($_POST['encrypt'])){
    if($_POST['nickname']!=''){
        ejecutar();
        $mail = new mailNotify();
        $mail->params($_POST['correo'],'Bienvenido a Phomework');
        $mail->send(
            $mail->mensajeEstudianteRegistro(
                $_POST['nickname'],
                $_POST['clave']
                ));
        echo '1';
    }
    else{
        echo 'NOPERMISOS';
    }
}
else{
    echo 'NO';
}


function ejecutar(){
    //incluir librerias de conexion
    include_once "conexion.php"; 
    $conexion = conexion();
    $nickname = $_POST['nickname'];
    $edad = $_POST['edad'];
    $telefono = $_POST['telefono'];
    $correo = $_POST['correo'];
    $clave = $_POST['clave'];
    $claverepeat = $_POST['claverepeat'];
    //encriptar clave con md5
    $encriptada= md5($clave);
    //ejecutar sentencia
    $profesores = mysqli_query($conexion,"SELECT * FROM profesores WHERE correo like '$correo' ") or die(mysqli_error($conexion));
    $estudiantes = mysqli_query($conexion,"SELECT * FROM estudiantes WHERE  correo like '$correo'") or die(mysqli_error($conexion));
    if(mysqli_num_rows($profesores)>0){
        echo 'Correo ya se encuentra registrado';
        exit();
    }
    elseif(mysqli_num_rows($estudiantes)>0){
        echo 'Correo ya se encuentra registrado';
        exit();
    }
    else{
        $sql = "INSERT INTO estudiantes (idestudiante, nickname, edad, telefono, correo, clave, PAYER_DNI, tipo, tokens) VALUES 
            (null,'$nickname', '$edad', '$telefono','$correo', '$encriptada', '$nickname', 'estudiante', '50');";
        mysqli_query($conexion, $sql) or die(mysqli_error($conexion)); 
        //agregar 50 tokens de regalo
        $estudiantes_ = mysqli_query($conexion,"SELECT * FROM estudiantes WHERE  correo like '$correo' ") or die(mysqli_error($conexion));
        $row = $estudiantes_->fetch_assoc();
        $id = $row['idestudiante'];
        $hoy = date('Y-m-d');
        $sql = "INSERT INTO `pagos` (`idpago`, `idestudiante`, `valor`, `signo`, `saldo`, `reference_pol`, `transactionId`, `responseCode`, `FIRMA`, `EMAILPAYER`, `DESCRIPTION`, `REFERENCE_CODE`, `fecha_creation`, `lapTransactionState`) VALUES (
          NULL, 
          $id, '10000', '+', '1500', 'regalo', 'regalo', 'regalo', 'regalo', 'regalo', 'regalo', 'regalo', '$hoy', '2017-08-08');";
        //mysqli_query($conexion, $sql) or die(mysqli_error($conexion));

        /*Integracion de notificacion*/
        $estudiantes = mysqli_query($conexion, "SELECT * FROM estudiantes WHERE  correo like '$correo'" ) or die(mysqli_error($conexion)); 
        include_once "notificaciones/onlyMessage.php";
        $docen = $estudiantes->fetch_assoc();
        $idestudiante = $docen['idestudiante'];
            $respuesta = sendMessage('Bienvenido a phomework App', $docen['tipo']);
            $sql = "INSERT INTO `notificaciones` (`id`, `titulo`, `texto`, `estudiante`, `docente`, `fecha_creado`, `fecha_actualizado`, `estado`) VALUES (NULL, 'Bienvenido a Phomework', 'Aprende con los docentes más calificados que tiene phomework para ti.  ', '$idestudiante', '0', '$hoy', '$hoy', '1');";
            mysqli_query($conexion, $sql) or die(mysqli_error($conexion));
    }    

}






?>