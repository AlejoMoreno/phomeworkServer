<?php 

/*include_once('Tareas.php');
$tareas = new Tareas();
$tareas->Constructor( '', 'tarea', NULL, '0', 'EN ESPERA', '93', '0', 'Esta es una tsrea. ', '2017-06-14', '2017-06-14', '1');
//$tareas->Insertar();
//print_r($tareas->Getall());
$tarea = $tareas->Getone(' WHERE `idestudiante` = 93 ');
//print_r($tarea);
echo $tareas->Update($tarea);*/


?>