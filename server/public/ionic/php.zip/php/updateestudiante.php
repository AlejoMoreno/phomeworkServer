<?php 
/***
Licencia por wakusoft
****/

if(isset($_POST['encrypt'])){
    if($_POST['correo']!=''){
        ejecutar();
        echo 'OK';
    }
    else{
        echo 'NOPERMISOS';
    }
}
else{
    echo 'NO';
}


function ejecutar(){
    //incluir librerias de conexion
    include_once "conexion.php"; 
    $conexion = conexion();
    $id = $_POST['id'];
    $edad = $_POST['edad'];
    $telefono = $_POST['telefono'];
    $correo = $_POST['correo'];
    $clave = $_POST['clave'];
    $claverepeat = $_POST['claverepeat'];
    //encriptar clave con md5
    $encriptada= md5($clave);
    //ejecutar sentencia
    $sql = "UPDATE `estudiantes` SET 
    `edad` = '$edad',
    `telefono` = '$telefono',
    `correo` = '$correo',
    `clave` = '$encriptada'
     WHERE `estudiantes`.`idestudiante` = $id;";
    mysqli_query($conexion, $sql) or die(mysqli_error($conexion)); 

}



?>