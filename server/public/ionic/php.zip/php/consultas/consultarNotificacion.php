<?php
/***
Licencia por wakusoft
****/

if(isset($_POST['encrypt'])){
    if($_POST['consulta']!=''){
        ejecutar($_POST['sentencia']);
    }
    else{
        echo 'NOPERMISOS';
    }
}
else{
    echo 'NO';
}

function ejecutar($sentencia){
	$id = $_POST['id'];
	$tipo = $_POST['consulta'];
	include_once "../conexion.php"; 
	$conexion = conexion();
	if($tipo=='docente'){
		$sql = "SELECT * FROM `notificaciones` WHERE `docente` = $id ORDER BY `notificaciones`.`id` DESC ";
	}
	else{
		$sql = "SELECT * FROM `notificaciones` WHERE `estudiante` = $id ORDER BY `notificaciones`.`id` DESC ";
	}
	$noti = mysqli_query($conexion,$sql) or die(mysqli_error($conexion));
	//verifiacciones
	while($row = $noti->fetch_assoc()){
		?>

		<div style="padding: 10px;margin: 10px;width: 100%;background: white;font-size: 14pt;"><?php echo $row['titulo'].'<br>'.$row['texto'].'<small>'.$row['fecha_creado'].'</small>' ?></div>

		<?php
	}

}

//1 pendiente

//2 habilitado

//3 inabilitado

?>