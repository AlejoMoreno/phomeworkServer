<?php
/***
Licencia por wakusoft
****/

if(isset($_POST['encrypt'])){
    if($_POST['consulta']!=''){
        ejecutar();
    }
    else{
        echo 'NOPERMISOS';
    }
}
else{
    echo 'NO';
}

function ejecutar(){
	//importar librerias de conexion
	include_once "../conexion.php"; 
	$conexion = conexion();
	//traer datos POST
	$areas = mysqli_query($conexion,"SELECT * FROM `areasespecialista`") or die(mysqli_error($conexion));
	//verifiacciones
	$resultado = '<select name="registerUseridareasEspecialista" id="registerUseridareasEspecialista" style="width: 100%;background: transparent;"> ';
	$resultado .='<option value="">SELECCIONE EL AREA A TRABAJAR</option>';
	while ($row = $areas->fetch_assoc()){
		$resultado .= '<option value="'.$row['idareasEspecialista'].'">'.$row['nombre'].'</option>';
	}
	$resultado .= '</select>';
	echo $resultado;
}
//1 pendiente
//2 habilitado
//3 inabilitado




?>