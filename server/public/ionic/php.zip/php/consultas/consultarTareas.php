<?php
/***
Licencia por wakusoft
****/

if(isset($_POST['encrypt'])){
    if($_POST['consulta']!=''){
        ejecutar($_POST['sentencia']);
    }
    else{
        echo 'NOPERMISOS';
    }
}
else{
    echo 'NO';
}

function ejecutar($sentencia){

	//importar librerias de conexion
	include_once('/home/leizycom/public_html/www/php/class/Tareas.php');
	//include_once('c://xampp/htdocs/www/php/class/Tareas.php');

	//echo 'Estamos en reparacion';	
	$tareas = new Tareas();
	$listaTareas = $tareas->Getone($sentencia);
	echo '<h1>CANTIDAD DE TAREAS: '.sizeof($listaTareas).'</h1>';
	if(sizeof($listaTareas)>0){
		foreach ($listaTareas as $tarea) {
			$calificacion = $tareas->calificacion($tarea['idtareas']);
			if($tarea['estado'] == 'EN ESPERA'){
				$estado = '<div class="panel-body" style="background:#207ce5;font-size:11px;">'.$tarea['estado'].'</div>';
			}
			elseif ($tarea['estado'] == 'SOLUCIONADO') {
				$estado = '<div class="panel-body" style="background:green;font-size:11px;">'.$tarea['estado'].'</div>';
			}
			else{
				$estado = '<div class="panel-body" style="background:#e73827;font-size:11px;">'.$tarea['estado'].'</div>';
			}
			echo '<div style="margin: 0px;width:100%;height:220px;border:2px solid white;">
					<a href="MostrarTarea.html?id='.$tarea['idtareas'].'&estudiante='.$tarea['idestudiante'].'&docente='.$tarea['idprofesor'].'"><div style="float: left;width: 100%;margin: 10px;background: transparent;">
						<p><strong>'.$tarea['nombre'].' <strong style="color:red">ID: '.$tarea['idtareas'].'</strong></strong>
						<br>'.substr($tarea['descripcion'],0,49).'... <strong style="font-size:11px"><br>Vence '.$tarea['fecha_vencimiento'].'<p style="color:green">Calificacion: '.$calificacion['calificacion'].'::'.$calificacion['comentarios'].'</p></strong>
						<br>
					</div></a>
					<div class="panel panel-default btdocente" style="width:100%;float:left">
		                '.$estado.'
		            </div>
				</div><hr>';
		}
	}
	else{
		echo '<div class="panel panel-default btdocente" style="width:100%;float:left">
	                <div class="panel-body" style="background:green;font-size:15px;">No tienes historial de tareas</div>
	            </div>';
	}

}

//1 pendiente

//2 habilitado

//3 inabilitado

?>