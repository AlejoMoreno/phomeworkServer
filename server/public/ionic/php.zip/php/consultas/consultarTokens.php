
<?php

/***

Licencia por wakusoft

****/



if(isset($_POST['encrypt'])){

    if($_POST['consulta']!=''){

        ejecutar();

    }

    else{

        echo 'NOPERMISOS';

    }

}

else{

    echo 'NO';

}



function ejecutar(){

	//importar librerias de conexion

	include_once "../conexion.php"; 

	$conexion = conexion();

	//traer datos POST

  	$idestudiante = $_POST['idestudiante'];

	$tokensid = mysqli_query($conexion,"SELECT * FROM `pagos` WHERE `idestudiante` = $idestudiante AND  `responseCode` NOT LIKE 'PENDING' ") or die(mysqli_error($conexion));

	//verifiacciones
	if($_POST['consulta'] == 'Cantidad'){
		$total = intval(0);
		while($row = $tokensid->fetch_assoc()){
			if($row['signo']=='+'){
				$total += intval($row['valor']);
			}
			elseif($row['signo']=='-'){
				$total -= intval($row['valor']);
			}	
		}
		$total = $total/1000;//mil pesos la unidad de token
		echo $total;
	}

	//verifiacciones
	if($_POST['consulta'] == 'historico'){
		?>

		<div class="container" style="color: black;overflow-x:scroll;">
		  <h2 style="background: #dbdbdb;opacity: 0.6;">Historial</h2>         
		  <table class="table">
		    <thead>
		      <tr>
		        <th><center>Valor</center></th>
		        <th style="background: #dbdbdb;opacity: 0.6;"><center>Signo</center></th>
		        <th><center>Código Transacción</center></th>
		        <th style="background: #dbdbdb;opacity: 0.6;"><center>Correo Pagador</center></th>
		        <th><center>Respuesta Payu</center></th>
		        <th style="background: #dbdbdb;opacity: 0.6;"><center>Fecha</center></th>
		      </tr>
		    </thead>
		    <tbody>
		    <?php 
		    $cont = 0;
		    while($row = $tokensid->fetch_assoc()){
		    	if($cont%2==0){
		    		echo '<tr style="background: #dbdbdb;opacity: 0.6;">
			        <td>'.$row['valor'].'</td>
			        <td>'.$row['signo'].'</td>
			        <td>'.$row['transactionId'].'</td>
			        <td>'.$row['EMAILPAYER'].'</td>
			        <td>'.$row['responseCode'].'</td>
			        <td>'.$row['fecha_creation'].'</td>
			      </tr>';
		    	}
		    	else{
		    		echo '<tr>
			        <td>'.$row['valor'].'</td>
			        <td>'.$row['signo'].'</td>
			        <td>'.$row['transactionId'].'</td>
			        <td>'.$row['EMAILPAYER'].'</td>
			        <td>'.$row['responseCode'].'</td>
			        <td>'.$row['fecha_creation'].'</td>
			      </tr>';
		    	}
		    	$cont++;
		    }
		      ?>
		    </tbody>
		  </table>
		</div>

		<?php 
	}

	

	

}

//1 pendiente

//2 habilitado

//3 inabilitado









?>