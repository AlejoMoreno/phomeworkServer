<?php
/***
Licencia por wakusoft
****/

if(isset($_POST['encrypt'])){
    if($_POST['correo']!=''){
        ejecutar();
    }
    else{
        echo 'NOPERMISOS';
    }
}
else{
    echo 'NO';
}

function ejecutar(){
	//importar librerias de conexion
	include_once "conexion.php"; 
	$conexion = conexion();
	//traer datos POST
	$correo = $_POST['correo'];
	$clave = $_POST['clave'];
	$pushID = $_POST['pushID'];
	$encriptado=md5($clave);
	$estudiantes = mysqli_query($conexion,"SELECT * FROM estudiantes WHERE  correo like '$correo'  AND clave like '$encriptado' ") or die(mysqli_error($conexion));
	$profesores = mysqli_query($conexion,"SELECT * FROM profesores WHERE correo like '$correo' AND clave like '$encriptado' ") or die(mysqli_error($conexion));
	//verifiacciones
	if ($row = $estudiantes->fetch_assoc()){
		$sql = "UPDATE `estudiantes` SET `tipo` = '$pushID' WHERE  correo like '$correo'  AND clave like '$encriptado'  ";
		mysqli_query($conexion,$sql) or die(mysqli_error($conexion));
		print_r(json_encode($row));
	}
	elseif($row1 = $profesores->fetch_assoc()){
		if($row1['estado']=='1'){
			$v2="Su cuenta no esta activa";
			print_r(json_encode($v2));
			exit();
		}
		else{
			$sql = "UPDATE `profesores` SET `tipo` = '$pushID' WHERE correo like '$correo' AND clave like '$encriptado' AND estado = 2 ";
			mysqli_query($conexion,$sql) or die(mysqli_error($conexion));
			print_r(json_encode(array('correo'=> $row1['correo'],'tipo'=> $row1['tipo'],'idestudiante'=> $row1['idprofesores'])));
		}		
	}
	else{
		$v2="Usuario o Clave, Son erradas .ddd".$row1['estado'];
		print_r(json_encode($v2));
	}
}
//1 pendiente
//2 habilitado
//3 inabilitado




?>